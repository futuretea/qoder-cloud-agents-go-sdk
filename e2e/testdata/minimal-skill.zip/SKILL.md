---
name: minimal
description: A minimal skill for e2e tests
version: 1.0.0
---

# Minimal

A minimal skill for e2e tests.
